
# Maven 示例工程
用于验证本地的 Maven 能否正常下载依赖 jar。

- 本项目只依赖了一个简单的时间库：joda-time



# 使用
### 编译
在当前目录下执行命令：
```
mvn clean package
```

若能执行成功，则说明 Maven 可正常下载到依赖的 jar。



### 运行
若是 IntelliJ IDEA 中：
1. 打开 `TestMain.java` 文件
1. 按下快捷键 `Ctrl + Shift + F10`，若看到输出 `Test OK` 则说明 Java 程序可正常运行。




