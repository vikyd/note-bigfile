import org.joda.time.DateTime;

public class TestMain {
    public static void main(String[] args) {
        System.out.println(new DateTime());
        System.out.println("Test OK.");
    }
}
